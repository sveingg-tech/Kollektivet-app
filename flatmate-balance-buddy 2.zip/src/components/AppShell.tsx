import { Link } from "@tanstack/react-router";
import { House, Plus, Receipt, User, Users } from "lucide-react";
import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

type AppShellProps = {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  children: ReactNode;
};

export function AppShell({ title, subtitle, right, children }: AppShellProps) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-[520px] flex-col bg-background">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/90 px-5 pt-5 pb-3 backdrop-blur-md">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate font-display text-[26px] leading-none font-bold">{title}</h1>
            {subtitle ? (
              <p className="mt-1.5 truncate text-[13px] text-muted-foreground">{subtitle}</p>
            ) : null}
          </div>
          {right}
        </div>
      </header>

      <main className="flex-1 px-5 pt-4 pb-32">{children}</main>

      <BottomNav />
    </div>
  );
}

const TABS = [
  { to: "/hjem", label: "Hjem", icon: House },
  { to: "/oppgjor", label: "Oppgjør", icon: Receipt },
  { to: "/gruppe", label: "Gruppe", icon: Users },
  { to: "/profil", label: "Profil", icon: User },
] as const;

function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-[520px] border-t border-border bg-card/95 px-2 pt-2 safe-bottom backdrop-blur-md">
      <div className="relative flex items-stretch justify-between">
        {TABS.slice(0, 2).map((tab) => (
          <NavTab key={tab.to} {...tab} />
        ))}

        <div className="flex w-16 shrink-0 justify-center">
          <Link
            to="/nytt"
            aria-label="Legg til utlegg"
            className="tap -mt-7 grid size-16 place-items-center rounded-full bg-accent text-accent-foreground shadow-raised ring-4 ring-background"
          >
            <Plus className="size-8" strokeWidth={2.6} />
          </Link>
        </div>

        {TABS.slice(2).map((tab) => (
          <NavTab key={tab.to} {...tab} />
        ))}
      </div>
    </nav>
  );
}

function NavTab({
  to,
  label,
  icon: Icon,
}: {
  to: (typeof TABS)[number]["to"];
  label: string;
  icon: typeof House;
}) {
  return (
    <Link
      to={to}
      className="tap flex flex-1 flex-col items-center gap-1 rounded-xl py-2 text-muted-foreground"
      activeProps={{ className: "text-primary" }}
    >
      {({ isActive }) => (
        <>
          <Icon className={cn("size-[22px]", isActive && "stroke-[2.4]")} />
          <span className="text-[11px] font-medium">{label}</span>
        </>
      )}
    </Link>
  );
}
