import { Link } from "@tanstack/react-router";

export function NoGroup() {
  return (
    <div className="rounded-3xl bg-card p-6 text-center shadow-card">
      <span className="text-4xl">🏠</span>
      <h2 className="mt-3 font-display text-xl font-bold">Du er ikke i et kollektiv ennå</h2>
      <p className="mt-2 text-[14px] text-muted-foreground">
        Lag en gruppe for kollektivet ditt, eller bli med i en som finnes med den unike koden.
      </p>
      <Link
        to="/gruppe"
        className="tap mt-5 flex w-full items-center justify-center rounded-2xl bg-primary py-3.5 font-display text-[15px] font-bold text-primary-foreground"
      >
        Kom i gang
      </Link>
    </div>
  );
}
