import { ChevronLeft, ChevronRight } from "lucide-react";

import { formatWeekRange, weekLabel, weekNumber } from "@/lib/week";

export function WeekPicker({
  monday,
  offset,
  onChange,
}: {
  monday: Date;
  offset: number;
  onChange: (offset: number) => void;
}) {
  return (
    <div className="flex items-center gap-2 rounded-2xl bg-card p-1.5 shadow-card">
      <button
        type="button"
        aria-label="Forrige uke"
        onClick={() => onChange(offset - 1)}
        className="tap grid size-9 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"
      >
        <ChevronLeft className="size-5" />
      </button>
      <div className="min-w-0 flex-1 text-center">
        <p className="font-display text-[15px] leading-none font-bold">
          {weekLabel(monday)} · uke {weekNumber(monday)}
        </p>
        <p className="mt-1 text-[12px] text-muted-foreground">{formatWeekRange(monday)}</p>
      </div>
      <button
        type="button"
        aria-label="Neste uke"
        onClick={() => onChange(offset + 1)}
        disabled={offset >= 0}
        className="tap grid size-9 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground disabled:opacity-35"
      >
        <ChevronRight className="size-5" />
      </button>
    </div>
  );
}
