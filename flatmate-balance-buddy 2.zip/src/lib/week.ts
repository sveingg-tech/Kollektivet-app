/** Week helpers — the app runs on Monday-to-Sunday Norwegian weeks. */

export function toISODate(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseISODate(value: string): Date {
  const [y, m, d] = value.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
}

/** Monday of the week that contains `date`. */
export function weekStart(date: Date = new Date()): Date {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = (d.getDay() + 6) % 7; // 0 = monday
  d.setDate(d.getDate() - day);
  return d;
}

export function weekEnd(monday: Date): Date {
  const d = new Date(monday);
  d.setDate(d.getDate() + 6);
  return d;
}

export function addWeeks(monday: Date, count: number): Date {
  const d = new Date(monday);
  d.setDate(d.getDate() + count * 7);
  return d;
}

/** ISO 8601 week number. */
export function weekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}

const MONTHS = [
  "jan",
  "feb",
  "mar",
  "apr",
  "mai",
  "jun",
  "jul",
  "aug",
  "sep",
  "okt",
  "nov",
  "des",
];

const DAYS = ["søndag", "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "lørdag"];
const DAYS_SHORT = ["søn", "man", "tir", "ons", "tor", "fre", "lør"];

export function formatDayLong(date: Date): string {
  return `${DAYS[date.getDay()]} ${date.getDate()}. ${MONTHS[date.getMonth()]}`;
}

export function formatDayShort(date: Date): string {
  return `${DAYS_SHORT[date.getDay()]} ${date.getDate()}.`;
}

export function formatWeekRange(monday: Date): string {
  const end = weekEnd(monday);
  return `${monday.getDate()}. ${MONTHS[monday.getMonth()]} – ${end.getDate()}. ${MONTHS[end.getMonth()]}`;
}

export function weekLabel(monday: Date): string {
  const current = weekStart();
  const diff = Math.round((monday.getTime() - current.getTime()) / (7 * 86400000));
  if (diff === 0) return "Denne uka";
  if (diff === -1) return "Forrige uke";
  if (diff === 1) return "Neste uke";
  return `Uke ${weekNumber(monday)}`;
}

/** Days left of the week, counting today. 0 means the week is over. */
export function daysLeftInWeek(monday: Date): number {
  const today = weekStart();
  if (monday.getTime() !== today.getTime()) return 0;
  const now = new Date();
  return 7 - ((now.getDay() + 6) % 7);
}
