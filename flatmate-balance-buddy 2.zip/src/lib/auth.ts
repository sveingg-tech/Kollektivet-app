import { supabase } from "@/integrations/supabase/client";

/**
 * The app signs people in with a username, not an email. Auth still needs an
 * email address, so we derive a deterministic internal one from the username.
 * It is never shown to the user and never receives mail.
 */
const INTERNAL_DOMAIN = "kollektivet.app";

export function normalizeUsername(username: string): string {
  return username.trim().toLowerCase();
}

export function usernameToEmail(username: string): string {
  return `${normalizeUsername(username)}@${INTERNAL_DOMAIN}`;
}

export function validateUsername(username: string): string | null {
  const value = normalizeUsername(username);
  if (value.length < 3) return "Brukernavn må ha minst 3 tegn";
  if (value.length > 24) return "Brukernavn kan ha maks 24 tegn";
  if (!/^[a-z0-9._-]+$/.test(value))
    return "Bruk kun bokstaver (a–z), tall, punktum, bindestrek eller understrek";
  return null;
}

export function validatePhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "");
  if (digits.length < 8) return "Telefonnummeret må ha minst 8 siffer";
  if (digits.length > 15) return "Telefonnummeret er for langt";
  return null;
}

export function validateEmail(email: string): string | null {
  const value = email.trim();
  if (value.length < 5) return "Skriv inn e-postadressen din";
  if (value.length > 255) return "E-postadressen er for lang";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) return "Ugyldig e-postadresse";
  return null;
}

export async function signUpWithUsername(input: {
  username: string;
  password: string;
  fullName: string;
  phone: string;
  email: string;
}) {
  const { error } = await supabase.auth.signUp({
    email: usernameToEmail(input.username),
    password: input.password,
    options: {
      data: {
        username: normalizeUsername(input.username),
        full_name: input.fullName.trim(),
        phone: input.phone.trim(),
        contact_email: input.email.trim().toLowerCase(),
      },
    },
  });
  return error;
}

export async function signInWithUsername(username: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({
    email: usernameToEmail(username),
    password,
  });
  return error;
}
