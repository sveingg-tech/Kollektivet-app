import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";

import { supabase } from "@/integrations/supabase/client";
import { toISODate } from "./week";

export type Profile = {
  id: string;
  username: string;
  full_name: string;
  phone: string;
  email: string;
};

export type Group = {
  id: string;
  name: string;
  join_code: string;
  created_by: string;
};

export type Expense = {
  id: string;
  group_id: string;
  paid_by: string;
  created_by: string;
  title: string;
  category: string;
  amount_ore: number;
  spent_on: string;
  week_start: string;
  note: string | null;
  created_at: string;
  participants: string[];
};

export type Settlement = {
  id: string;
  from_user: string;
  to_user: string;
  amount_ore: number;
  paid_at: string;
};

/* ---------------------------------- auth --------------------------------- */

export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!active) return;
      setUser(data.user ?? null);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { user, ready };
}

export function useMyProfile(userId: string | undefined) {
  return useQuery({
    queryKey: ["profile", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Profile | null> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, full_name, phone, email")
        .eq("id", userId!)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

/* --------------------------------- groups -------------------------------- */

export function useMyGroups() {
  return useQuery({
    queryKey: ["my-groups"],
    queryFn: async (): Promise<Group[]> => {
      const { data, error } = await supabase
        .from("groups")
        .select("id, name, join_code, created_by")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useMembers(groupId: string | undefined) {
  return useQuery({
    queryKey: ["members", groupId],
    enabled: !!groupId,
    queryFn: async (): Promise<Profile[]> => {
      const { data: rows, error } = await supabase
        .from("group_members")
        .select("user_id")
        .eq("group_id", groupId!);
      if (error) throw error;
      const ids = (rows ?? []).map((r) => r.user_id);
      if (ids.length === 0) return [];
      const { data: profiles, error: pErr } = await supabase
        .from("profiles")
        .select("id, username, full_name, phone, email")
        .in("id", ids);
      if (pErr) throw pErr;
      return (profiles ?? []).sort((a, b) => a.full_name.localeCompare(b.full_name, "nb"));
    },
  });
}

export function useCreateGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (name: string) => {
      const { data, error } = await supabase.rpc("create_group", { _name: name });
      if (error) throw error;
      return data as unknown as Group;
    },
    onSuccess: () => qc.invalidateQueries(),
  });
}

export function useJoinGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (code: string) => {
      const { data, error } = await supabase.rpc("join_group", { _code: code });
      if (error) throw error;
      return data as unknown as Group;
    },
    onSuccess: () => qc.invalidateQueries(),
  });
}

export function useLeaveGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { groupId: string; userId: string }) => {
      const { error } = await supabase
        .from("group_members")
        .delete()
        .eq("group_id", input.groupId)
        .eq("user_id", input.userId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries(),
  });
}

/* -------------------------------- expenses ------------------------------- */

export function useWeekExpenses(groupId: string | undefined, monday: Date) {
  const week = toISODate(monday);
  return useQuery({
    queryKey: ["expenses", groupId, week],
    enabled: !!groupId,
    queryFn: async (): Promise<Expense[]> => {
      const { data, error } = await supabase
        .from("expenses")
        .select(
          "id, group_id, paid_by, created_by, title, category, amount_ore, spent_on, week_start, note, created_at, expense_shares(user_id)",
        )
        .eq("group_id", groupId!)
        .eq("week_start", week)
        .order("spent_on", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((row) => {
        const { expense_shares, ...rest } = row as typeof row & {
          expense_shares: { user_id: string }[];
        };
        return { ...rest, participants: (expense_shares ?? []).map((s) => s.user_id) } as Expense;
      });
    },
  });
}

export function useAddExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      groupId: string;
      userId: string;
      paidBy: string;
      title: string;
      category: string;
      amountOre: number;
      spentOn: Date;
      weekStart: Date;
      participants: string[];
      note?: string;
    }) => {
      const { data, error } = await supabase
        .from("expenses")
        .insert({
          group_id: input.groupId,
          paid_by: input.paidBy,
          created_by: input.userId,
          title: input.title,
          category: input.category,
          amount_ore: input.amountOre,
          spent_on: toISODate(input.spentOn),
          week_start: toISODate(input.weekStart),
          note: input.note ?? null,
        })
        .select("id")
        .single();
      if (error) throw error;

      const shares = input.participants.map((user_id) => ({ expense_id: data.id, user_id }));
      if (shares.length > 0) {
        const { error: sErr } = await supabase.from("expense_shares").insert(shares);
        if (sErr) throw sErr;
      }
      return data.id;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expenses"] }),
  });
}

export function useDeleteExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expenses"] }),
  });
}

/* ------------------------------ settlements ------------------------------ */

export function useSettlements(groupId: string | undefined, monday: Date) {
  const week = toISODate(monday);
  return useQuery({
    queryKey: ["settlements", groupId, week],
    enabled: !!groupId,
    queryFn: async (): Promise<Settlement[]> => {
      const { data, error } = await supabase
        .from("settlements")
        .select("id, from_user, to_user, amount_ore, paid_at")
        .eq("group_id", groupId!)
        .eq("week_start", week);
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useMarkPaid() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      groupId: string;
      weekStart: Date;
      fromUser: string;
      toUser: string;
      amountOre: number;
    }) => {
      const { error } = await supabase.from("settlements").upsert(
        {
          group_id: input.groupId,
          week_start: toISODate(input.weekStart),
          from_user: input.fromUser,
          to_user: input.toUser,
          amount_ore: input.amountOre,
        },
        { onConflict: "group_id,week_start,from_user,to_user" },
      );
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settlements"] }),
  });
}

export function useUndoPaid() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("settlements").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settlements"] }),
  });
}
