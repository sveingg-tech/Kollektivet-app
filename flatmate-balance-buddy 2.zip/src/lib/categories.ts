export type CategoryKey =
  | "mat"
  | "vask"
  | "dopapir"
  | "mobler"
  | "strom"
  | "snacks"
  | "kjokken"
  | "fest"
  | "verktoy"
  | "annet";

export type Category = {
  key: CategoryKey;
  label: string;
  emoji: string;
  examples: string;
};

export const CATEGORIES: Category[] = [
  { key: "mat", label: "Felles mat", emoji: "🍕", examples: "Pizza, taco, søndagsmiddag" },
  { key: "vask", label: "Vaskeutstyr", emoji: "🧽", examples: "Zalo, klorin, kluter, tørkerull" },
  { key: "dopapir", label: "Dopapir", emoji: "🧻", examples: "Dopapir, såpe, tannkrem" },
  { key: "mobler", label: "Møbler", emoji: "🛋️", examples: "Ødelagt stol, ny sofa, lampe" },
  { key: "strom", label: "Strøm & nett", emoji: "💡", examples: "Strøm, wifi, TV-pakke" },
  { key: "snacks", label: "Snacks & drikke", emoji: "🥤", examples: "Kaffe, brus, chips" },
  { key: "kjokken", label: "Kjøkken", emoji: "🍳", examples: "Olje, salt, kaffefilter, oppvaskkost" },
  { key: "fest", label: "Vorspiel", emoji: "🎉", examples: "Snacks til fest, pynt, pant" },
  { key: "verktoy", label: "Verktøy & fiks", emoji: "🔧", examples: "Lyspærer, batterier, skruer" },
  { key: "annet", label: "Annet", emoji: "📦", examples: "Alt annet felles" },
];

export function categoryOf(key: string): Category {
  return CATEGORIES.find((c) => c.key === key) ?? CATEGORIES[CATEGORIES.length - 1]!;
}
