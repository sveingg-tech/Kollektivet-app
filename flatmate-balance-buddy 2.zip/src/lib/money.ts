/** All amounts are stored as integer øre (1 kr = 100 øre). */

export function formatKr(ore: number, opts: { decimals?: boolean } = {}): string {
  const kr = ore / 100;
  const showDecimals = opts.decimals ?? Math.abs(ore % 100) !== 0;
  return kr.toLocaleString("nb-NO", {
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: showDecimals ? 2 : 0,
  });
}

export function formatKrSigned(ore: number): string {
  const sign = ore > 0 ? "+" : ore < 0 ? "−" : "";
  return `${sign}${formatKr(Math.abs(ore))} kr`;
}

/** Parse a user-typed amount ("129", "129,50", "129.50") into øre. */
export function parseKrToOre(input: string): number | null {
  const cleaned = input.replace(/\s/g, "").replace(",", ".");
  if (!cleaned || !/^\d*\.?\d*$/.test(cleaned)) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value <= 0) return null;
  return Math.round(value * 100);
}

/**
 * Split `total` øre between `count` people without losing a single øre.
 * The remainder is spread over the first people in the list.
 */
export function splitEvenly(total: number, count: number): number[] {
  if (count <= 0) return [];
  const base = Math.floor(total / count);
  let rest = total - base * count;
  return Array.from({ length: count }, () => {
    const extra = rest > 0 ? 1 : 0;
    rest -= extra;
    return base + extra;
  });
}
