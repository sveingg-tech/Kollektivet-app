import { splitEvenly } from "./money";

export type ExpenseRow = {
  id: string;
  paid_by: string;
  amount_ore: number;
  participants: string[];
};

export type Balance = { userId: string; net: number };

export type Transfer = { from: string; to: string; amount: number };

/**
 * Net position per user in øre.
 * Positive = the others owe them money. Negative = they owe money.
 */
export function computeBalances(expenses: ExpenseRow[], memberIds: string[]): Balance[] {
  const net = new Map<string, number>(memberIds.map((id) => [id, 0]));
  const bump = (id: string, delta: number) => net.set(id, (net.get(id) ?? 0) + delta);

  for (const e of expenses) {
    const parts = e.participants.length > 0 ? e.participants : [e.paid_by];
    bump(e.paid_by, e.amount_ore);
    const shares = splitEvenly(e.amount_ore, parts.length);
    parts.forEach((id, i) => bump(id, -(shares[i] ?? 0)));
  }

  return [...net.entries()].map(([userId, value]) => ({ userId, net: value }));
}

/**
 * Greedy settlement: fewest possible transfers that clear all balances.
 */
export function computeTransfers(balances: Balance[]): Transfer[] {
  const debtors = balances
    .filter((b) => b.net < 0)
    .map((b) => ({ ...b, net: -b.net }))
    .sort((a, b) => b.net - a.net);
  const creditors = balances
    .filter((b) => b.net > 0)
    .map((b) => ({ ...b }))
    .sort((a, b) => b.net - a.net);

  const transfers: Transfer[] = [];
  let i = 0;
  let j = 0;
  while (i < debtors.length && j < creditors.length) {
    const debtor = debtors[i]!;
    const creditor = creditors[j]!;
    const amount = Math.min(debtor.net, creditor.net);
    if (amount > 0) {
      transfers.push({ from: debtor.userId, to: creditor.userId, amount });
      debtor.net -= amount;
      creditor.net -= amount;
    }
    if (debtor.net <= 0) i++;
    if (creditor.net <= 0) j++;
  }
  return transfers;
}
