/**
 * Vipps hand-off. Vipps has no public "send money" web API for consumers, so we
 * open the app with a prefilled deep link and always show the raw number +
 * amount as a fallback the user can type or copy manually.
 */

export function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  return digits.startsWith("47") && digits.length === 10 ? digits.slice(2) : digits;
}

export function vippsLink(opts: { phone: string; ore: number; message: string }): string {
  const phone = normalizePhone(opts.phone);
  const kr = (opts.ore / 100).toFixed(2);
  const params = new URLSearchParams({
    phoneNumber: phone,
    amount: kr,
    message: opts.message,
  });
  return `vipps://send?${params.toString()}`;
}

export function vippsFallbackLink(): string {
  return "https://vipps.no/produkter-og-tjenester/privat/sende-og-be-om-penger/";
}
