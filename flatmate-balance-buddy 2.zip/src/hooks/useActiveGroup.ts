import { useEffect, useState } from "react";

import { useMyGroups, type Group } from "@/lib/data";

const KEY = "kollektivet.activeGroup";

export function useActiveGroup() {
  const groups = useMyGroups();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    setSelectedId(window.localStorage.getItem(KEY));
  }, []);

  const list = groups.data ?? [];
  const active: Group | undefined = list.find((g) => g.id === selectedId) ?? list[0];

  function selectGroup(id: string) {
    setSelectedId(id);
    if (typeof window !== "undefined") window.localStorage.setItem(KEY, id);
  }

  return { groups: list, group: active, selectGroup, isLoading: groups.isLoading };
}
