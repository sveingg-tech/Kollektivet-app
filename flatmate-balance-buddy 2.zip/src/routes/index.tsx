import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

import { useUser } from "@/lib/data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Kollektivet – del fellesutgifter i kollektivet, uke for uke" },
      {
        name: "description",
        content:
          "Hold oversikt over pizza, vaskeutstyr, dopapir og ødelagte møbler i kollektivet. Legg inn utlegg fortløpende, og gjør opp med Vipps på slutten av uka.",
      },
      { property: "og:title", content: "Kollektivet – ukesoppgjør for fellesutgifter" },
      {
        property: "og:description",
        content:
          "Lag en gruppe med koden, legg inn utlegg, og trykk BETAL HER for et ferdig utfylt Vipps-oppgjør.",
      },
    ],
  }),
  component: Landing,
});

const HIGHLIGHTS = [
  { emoji: "🍕", title: "Pizza på fredag", text: "Legg inn utlegget på 5 sekunder" },
  { emoji: "🧻", title: "Dopapir og Zalo", text: "Deles automatisk på alle som bor der" },
  { emoji: "🛋️", title: "Ødelagt stol", text: "Velg selv hvem utlegget skal deles på" },
];

function Landing() {
  const { user, ready } = useUser();
  const navigate = useNavigate();

  useEffect(() => {
    if (ready && user) navigate({ to: "/hjem", replace: true });
  }, [ready, user, navigate]);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-[520px] flex-col px-6 pt-14 pb-10">
      <div className="flex items-center gap-3">
        <span className="grid size-11 place-items-center rounded-2xl bg-primary font-display text-xl font-bold text-primary-foreground">
          K
        </span>
        <p className="font-display text-lg font-bold">Kollektivet</p>
      </div>

      <h1 className="mt-10 font-display text-[42px] leading-[0.95] font-bold">
        Fellesutgifter,
        <br />
        <span className="text-primary">gjort opp hver uke.</span>
      </h1>
      <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
        Lag en gruppe med de du bor med, legg inn utleggene fortløpende, og få et ferdig
        Vipps-oppgjør på søndag. Ingen krangling om hvem som kjøpte dopapiret.
      </p>

      <ul className="mt-8 space-y-3">
        {HIGHLIGHTS.map((h) => (
          <li
            key={h.title}
            className="flex items-center gap-3 rounded-2xl bg-card p-3.5 shadow-card"
          >
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-secondary text-xl">
              {h.emoji}
            </span>
            <div>
              <p className="text-[15px] font-medium">{h.title}</p>
              <p className="text-[13px] text-muted-foreground">{h.text}</p>
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-auto pt-10">
        <Link
          to="/auth"
          search={{ modus: "ny" }}
          className="tap flex w-full items-center justify-center rounded-2xl bg-primary py-4 font-display text-base font-bold text-primary-foreground shadow-raised"
        >
          Lag bruker
        </Link>
        <Link
          to="/auth"
          search={{ modus: "logg-inn" }}
          className="tap mt-3 flex w-full items-center justify-center rounded-2xl border border-border bg-card py-4 font-display text-base font-bold"
        >
          Jeg har bruker
        </Link>
      </div>
    </div>
  );
}
