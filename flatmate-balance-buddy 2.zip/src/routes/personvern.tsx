import { createFileRoute, Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export const Route = createFileRoute("/personvern")({
  head: () => ({
    meta: [
      { title: "Personvernerklæring (Privacy Policy) – Kollektivet" },
      {
        name: "description",
        content:
          "Hvilke opplysninger Kollektivet samler inn, hvorfor, hvor lenge de lagres, og hvordan du sletter brukeren din.",
      },
      { property: "og:title", content: "Personvernerklæring – Kollektivet" },
      {
        property: "og:description",
        content: "Slik behandler Kollektivet personopplysningene dine.",
      },
    ],
  }),
  component: PrivacyPage,
});

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-7">
      <h2 className="font-display text-lg font-bold">{title}</h2>
      <div className="mt-2 space-y-2 text-[14.5px] leading-relaxed text-muted-foreground">
        {children}
      </div>
    </section>
  );
}

function PrivacyPage() {
  return (
    <div className="mx-auto w-full max-w-[640px] px-6 pt-12 pb-16">
      <Link to="/" className="text-[13px] text-muted-foreground">
        ← Tilbake
      </Link>
      <h1 className="mt-6 font-display text-[32px] leading-none font-bold">Personvernerklæring</h1>
      <p className="mt-2 text-[13px] text-muted-foreground">Privacy Policy · Sist oppdatert 5. oktober 2026</p>

      <Section title="Hvem vi er">
        <p>
          Kollektivet er en app for å dele fellesutgifter i et kollektiv. Behandlingsansvarlig er
          utvikleren av Kollektivet. Spørsmål om personvern kan sendes til
          <strong> personvern@kollektivet.app</strong>.
        </p>
      </Section>

      <Section title="Hvilke opplysninger vi samler inn">
        <ul className="list-disc space-y-1 pl-5">
          <li>Kontaktinformasjon: navn, brukernavn, e-postadresse og telefonnummer.</li>
          <li>Innloggingsdata: passordet ditt lagres kun kryptert (hashet).</li>
          <li>
            Brukerinnhold: grupper du er med i, utlegg du legger inn (beløp, beskrivelse,
            kategori, dato) og registrerte oppgjør.
          </li>
        </ul>
        <p>
          Vi samler ikke inn posisjon, kontakter, bilder, helsedata eller annonse-ID, og vi bruker
          ikke sporing (tracking) på tvers av apper og nettsteder.
        </p>
      </Section>

      <Section title="Hvorfor vi bruker opplysningene">
        <p>
          Opplysningene brukes kun for at appen skal fungere: logge deg inn, vise utlegg til de
          andre i gruppa, beregne hvem som skylder hva, og lage en Vipps-lenke med telefonnummer og
          beløp til den som skal motta oppgjøret. Telefonnummer og navn ditt er synlig for
          medlemmene i gruppene dine.
        </p>
        <p>Vi bruker ikke opplysningene til reklame, profilering eller salg.</p>
      </Section>

      <Section title="Deling med tredjeparter">
        <p>
          Vi selger aldri data. Opplysningene lagres hos vår driftsleverandør for database og
          innlogging, som kun behandler data på våre vegne. Når du trykker «BETAL HER» åpnes Vipps
          med nummer og beløp – videre behandling skjer etter Vipps sin egen personvernerklæring.
        </p>
      </Section>

      <Section title="Lagring og sletting">
        <p>
          Opplysningene lagres så lenge du har en bruker. Du kan når som helst slette brukeren din
          inne i appen under <strong>Profil → Slett bruker</strong>. Da slettes profilen din,
          medlemskap, utlegg og oppgjør du er knyttet til, og grupper du har opprettet, permanent.
        </p>
      </Section>

      <Section title="Dine rettigheter">
        <p>
          Du har rett til innsyn, retting, sletting, begrensning og dataportabilitet, og til å
          klage til Datatilsynet. Du kan rette opplysningene dine selv under Profil, eller kontakte
          oss på e-post.
        </p>
      </Section>

      <Section title="Sikkerhet">
        <p>
          All trafikk er kryptert (HTTPS), og tilgang til data er begrenset slik at du kun ser
          data fra gruppene du er medlem av.
        </p>
      </Section>

      <Section title="Barn">
        <p>Appen er ikke rettet mot barn under 13 år, og vi samler ikke bevisst inn data fra dem.</p>
      </Section>

      <Section title="Endringer">
        <p>Vesentlige endringer i erklæringen varsles i appen, og datoen øverst oppdateres.</p>
      </Section>
    </div>
  );
}
