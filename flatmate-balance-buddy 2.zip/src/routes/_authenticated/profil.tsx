import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { deleteMyAccount } from "@/lib/account.functions";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { AppShell } from "@/components/AppShell";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useActiveGroup } from "@/hooks/useActiveGroup";
import { validateEmail, validatePhone } from "@/lib/auth";
import { useLeaveGroup, useMyProfile, useUser } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/profil")({
  head: () => ({
    meta: [
      { title: "Profil – Kollektivet" },
      {
        name: "description",
        content:
          "Oppdater navn og Vipps-nummer, forlat kollektivet eller logg ut av Kollektivet-appen.",
      },
      { property: "og:title", content: "Profil – Kollektivet" },
      {
        property: "og:description",
        content: "Navnet og nummeret ditt brukes til Vipps-oppgjøret i kollektivet.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useUser();
  const profile = useMyProfile(user?.id);
  const { group } = useActiveGroup();
  const leaveGroup = useLeaveGroup();

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const deleteAccount = useServerFn(deleteMyAccount);

  useEffect(() => {
    if (profile.data) {
      setFullName(profile.data.full_name);
      setPhone(profile.data.phone);
      setEmail(profile.data.email ?? "");
    }
  }, [profile.data]);

  async function save() {
    if (!user) return;
    if (fullName.trim().length < 2) {
      toast.error("Skriv inn navnet ditt");
      return;
    }
    const phoneError = validatePhone(phone);
    if (phoneError) {
      toast.error(phoneError);
      return;
    }
    const emailError = validateEmail(email);
    if (emailError) {
      toast.error(emailError);
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName.trim(),
        phone: phone.replace(/\s/g, ""),
        email: email.trim().toLowerCase(),
      })
      .eq("id", user.id);
    setSaving(false);
    if (error) {
      toast.error("Klarte ikke å lagre");
      return;
    }
    await queryClient.invalidateQueries();
    toast.success("Lagret");
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { modus: "logg-inn" }, replace: true });
  }

  async function removeAccount() {
    const ok = window.confirm(
      "Er du sikker? Brukeren din, utleggene dine og grupper du har laget slettes for godt. Dette kan ikke angres.",
    );
    if (!ok) return;
    setDeleting(true);
    try {
      await deleteAccount();
      await queryClient.cancelQueries();
      queryClient.clear();
      await supabase.auth.signOut();
      toast.success("Brukeren er slettet");
      navigate({ to: "/", replace: true });
    } catch {
      setDeleting(false);
      toast.error("Klarte ikke å slette brukeren");
    }
  }

  async function leave() {
    if (!group || !user) return;
    try {
      await leaveGroup.mutateAsync({ groupId: group.id, userId: user.id });
      toast.success(`Du har forlatt ${group.name}`);
    } catch {
      toast.error("Klarte ikke å forlate gruppa");
    }
  }

  return (
    <AppShell title="Profil" subtitle={profile.data ? `@${profile.data.username}` : ""}>
      <section className="rounded-3xl bg-card p-5 shadow-card">
        <h2 className="font-display text-lg font-bold">Om deg</h2>
        <div className="mt-4 space-y-4">
          <div className="space-y-1.5">
            <Label className="text-[13px] text-muted-foreground">Navn</Label>
            <Input
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="h-13 rounded-xl bg-secondary text-base"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[13px] text-muted-foreground">E-post</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoCapitalize="none"
              inputMode="email"
              placeholder="mari@epost.no"
              className="h-13 rounded-xl bg-secondary text-base"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[13px] text-muted-foreground">Telefonnummer (Vipps)</Label>
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              inputMode="tel"
              className="h-13 rounded-xl bg-secondary text-base"
            />
            <p className="text-[12.5px] text-muted-foreground">
              Nummeret de andre sender oppgjøret til med Vipps.
            </p>
          </div>
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="tap flex w-full items-center justify-center rounded-2xl bg-primary py-3.5 font-display text-[15px] font-bold text-primary-foreground disabled:opacity-60"
          >
            {saving ? "Lagrer…" : "Lagre"}
          </button>
        </div>
      </section>

      <section className="mt-4 space-y-2.5">
        {group ? (
          <button
            type="button"
            onClick={leave}
            className="tap flex w-full items-center justify-center rounded-2xl border border-border bg-card py-3.5 text-[15px] font-medium text-negative"
          >
            Forlat {group.name}
          </button>
        ) : null}
        <button
          type="button"
          onClick={signOut}
          className="tap flex w-full items-center justify-center rounded-2xl border border-border bg-card py-3.5 text-[15px] font-medium"
        >
          Logg ut
        </button>
        <button
          type="button"
          onClick={removeAccount}
          disabled={deleting}
          className="tap flex w-full items-center justify-center rounded-2xl border border-negative/40 bg-card py-3.5 text-[15px] font-medium text-negative disabled:opacity-60"
        >
          {deleting ? "Sletter…" : "Slett bruker"}
        </button>
        <Link
          to="/personvern"
          className="block pt-2 text-center text-[13px] text-muted-foreground underline"
        >
          Personvernerklæring
        </Link>
      </section>
    </AppShell>
  );
}
