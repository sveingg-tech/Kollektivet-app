import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check, Delete } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { AppShell } from "@/components/AppShell";
import { NoGroup } from "@/components/NoGroup";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useActiveGroup } from "@/hooks/useActiveGroup";
import { CATEGORIES, categoryOf, type CategoryKey } from "@/lib/categories";
import { useAddExpense, useMembers, useUser } from "@/lib/data";
import { formatKr, parseKrToOre } from "@/lib/money";
import { cn } from "@/lib/utils";
import { formatDayShort, toISODate, weekStart } from "@/lib/week";

export const Route = createFileRoute("/_authenticated/nytt")({
  head: () => ({
    meta: [
      { title: "Nytt utlegg – Kollektivet" },
      {
        name: "description",
        content:
          "Legg inn et fellesutlegg på sekunder: beløp, kategori, hvem som betalte og hvem det deles på.",
      },
      { property: "og:title", content: "Nytt utlegg – Kollektivet" },
      {
        property: "og:description",
        content: "Registrer et fellesutlegg i kollektivet på under ti sekunder.",
      },
    ],
  }),
  component: NewExpensePage,
});

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ",", "0", "del"] as const;

function weekDays(): Date[] {
  const monday = weekStart();
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(d.getDate() + i);
    return d;
  }).filter((d) => d.getTime() <= Date.now());
}

function NewExpensePage() {
  const navigate = useNavigate();
  const { user } = useUser();
  const { group } = useActiveGroup();
  const members = useMembers(group?.id);
  const addExpense = useAddExpense();

  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState<CategoryKey>("mat");
  const [title, setTitle] = useState("");
  const [paidBy, setPaidBy] = useState<string>("");
  const [participants, setParticipants] = useState<string[]>([]);
  const [spentOn, setSpentOn] = useState(toISODate(new Date()));

  const memberList = members.data ?? [];

  useEffect(() => {
    if (user?.id && !paidBy) setPaidBy(user.id);
  }, [user?.id, paidBy]);

  useEffect(() => {
    if (memberList.length > 0 && participants.length === 0) {
      setParticipants(memberList.map((m) => m.id));
    }
  }, [memberList, participants.length]);

  const ore = parseKrToOre(amount) ?? 0;
  const perPerson = participants.length > 0 ? Math.round(ore / participants.length) : 0;

  function press(key: string) {
    if (key === "del") {
      setAmount((prev) => prev.slice(0, -1));
      return;
    }
    if (key === "," && (amount.includes(",") || amount === "")) return;
    if (amount.replace(",", "").length >= 7) return;
    const decimals = amount.split(",")[1];
    if (decimals && decimals.length >= 2) return;
    setAmount((prev) => (prev === "0" && key !== "," ? key : prev + key));
  }

  function toggleParticipant(id: string) {
    setParticipants((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id],
    );
  }

  async function submit() {
    if (!group || !user) return;
    if (ore <= 0) {
      toast.error("Skriv inn et beløp");
      return;
    }
    if (participants.length === 0) {
      toast.error("Velg minst én person utlegget skal deles på");
      return;
    }
    const spent = new Date(spentOn + "T12:00:00");
    try {
      await addExpense.mutateAsync({
        groupId: group.id,
        userId: user.id,
        paidBy: paidBy || user.id,
        title: title.trim() || categoryOf(category).label,
        category,
        amountOre: ore,
        spentOn: spent,
        weekStart: weekStart(spent),
        participants,
      });
      toast.success("Utlegget er lagt inn");
      navigate({ to: "/hjem" });
    } catch {
      toast.error("Klarte ikke å lagre utlegget");
    }
  }

  if (!group) {
    return (
      <AppShell title="Nytt utlegg">
        <NoGroup />
      </AppShell>
    );
  }

  return (
    <AppShell title="Nytt utlegg" subtitle={group.name}>
      <div className="rounded-3xl bg-card p-5 text-center shadow-card">
        <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">Beløp</p>
        <p className="money mt-1 text-[46px] leading-none font-bold">
          {amount === "" ? "0" : amount} <span className="text-2xl text-muted-foreground">kr</span>
        </p>
        <p className="mt-2 text-[13px] text-muted-foreground">
          {participants.length > 0 && ore > 0
            ? `${formatKr(perPerson)} kr per person (${participants.length})`
            : "Deles likt på de du velger"}
        </p>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2">
        {KEYS.map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => press(key)}
            className="tap grid h-14 place-items-center rounded-2xl bg-card font-display text-2xl font-bold shadow-card"
            aria-label={key === "del" ? "Slett siffer" : key}
          >
            {key === "del" ? <Delete className="size-6 text-muted-foreground" /> : key}
          </button>
        ))}
      </div>

      <Section label="Hva er det?">
        <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => setCategory(c.key)}
              className={cn(
                "tap shrink-0 rounded-full px-3.5 py-2 text-[13.5px] font-medium",
                category === c.key
                  ? "bg-accent text-accent-foreground"
                  : "bg-card text-foreground shadow-card",
              )}
            >
              {c.emoji} {c.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[12.5px] text-muted-foreground">{categoryOf(category).examples}</p>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={60}
          placeholder={`Beskrivelse (valgfritt) – f.eks. «${categoryOf(category).examples.split(",")[0]}»`}
          className="mt-3 h-13 rounded-xl bg-card text-base"
        />
      </Section>

      <Section label="Hvem la ut?">
        <div className="flex flex-wrap gap-2">
          {memberList.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setPaidBy(m.id)}
              className={cn(
                "tap rounded-full px-3.5 py-2 text-[13.5px] font-medium",
                paidBy === m.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground shadow-card",
              )}
            >
              {m.id === user?.id ? "Jeg" : m.full_name}
            </button>
          ))}
        </div>
      </Section>

      <Section label="Deles på">
        <div className="space-y-2">
          {memberList.map((m) => {
            const on = participants.includes(m.id);
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => toggleParticipant(m.id)}
                className="tap flex w-full items-center gap-3 rounded-2xl bg-card p-3 text-left shadow-card"
              >
                <span
                  className={cn(
                    "grid size-6 place-items-center rounded-md border",
                    on ? "border-primary bg-primary text-primary-foreground" : "border-border",
                  )}
                >
                  {on ? <Check className="size-4" strokeWidth={3} /> : null}
                </span>
                <span className="flex-1 text-[15px] font-medium">
                  {m.id === user?.id ? `${m.full_name} (deg)` : m.full_name}
                </span>
                {on && ore > 0 ? (
                  <span className="money text-[14px] text-muted-foreground">
                    {formatKr(perPerson)} kr
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      </Section>

      <Section label="Når?">
        <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
          {weekDays().map((d) => {
            const value = toISODate(d);
            return (
              <button
                key={value}
                type="button"
                onClick={() => setSpentOn(value)}
                className={cn(
                  "tap shrink-0 rounded-full px-3.5 py-2 text-[13.5px] font-medium",
                  spentOn === value
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-foreground shadow-card",
                )}
              >
                {formatDayShort(d)}
              </button>
            );
          })}
        </div>
      </Section>

      <button
        type="button"
        onClick={submit}
        disabled={addExpense.isPending}
        className="tap mt-6 flex w-full items-center justify-center rounded-2xl bg-primary py-4 font-display text-base font-bold text-primary-foreground shadow-raised disabled:opacity-60"
      >
        {addExpense.isPending ? "Lagrer…" : "Legg til utlegg"}
      </button>
    </AppShell>
  );
}

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <Label className="text-[13px] tracking-wide text-muted-foreground uppercase">{label}</Label>
      <div className="mt-2.5">{children}</div>
    </div>
  );
}
