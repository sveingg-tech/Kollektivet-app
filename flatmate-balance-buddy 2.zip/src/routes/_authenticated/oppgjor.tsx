import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { AppShell } from "@/components/AppShell";
import { NoGroup } from "@/components/NoGroup";
import { WeekPicker } from "@/components/WeekPicker";
import { useActiveGroup } from "@/hooks/useActiveGroup";
import {
  useMarkPaid,
  useMembers,
  useSettlements,
  useUndoPaid,
  useUser,
  useWeekExpenses,
} from "@/lib/data";
import { formatKr } from "@/lib/money";
import { computeBalances, computeTransfers } from "@/lib/settle";
import { normalizePhone, vippsLink } from "@/lib/vipps";
import { addWeeks, formatWeekRange, weekNumber, weekStart } from "@/lib/week";

export const Route = createFileRoute("/_authenticated/oppgjor")({
  head: () => ({
    meta: [
      { title: "Ukens oppgjør – Kollektivet" },
      {
        name: "description",
        content:
          "Se hvem som skylder hvem etter ukas fellesutgifter, og betal med et ferdig utfylt Vipps-oppgjør.",
      },
      { property: "og:title", content: "Ukens oppgjør – Kollektivet" },
      {
        property: "og:description",
        content: "Færrest mulige overføringer, ferdig utfylt beløp og nummer til Vipps.",
      },
    ],
  }),
  component: SettlementPage,
});

function SettlementPage() {
  const { user } = useUser();
  const { group } = useActiveGroup();
  const [offset, setOffset] = useState(0);
  const monday = useMemo(() => addWeeks(weekStart(), offset), [offset]);

  const members = useMembers(group?.id);
  const expenses = useWeekExpenses(group?.id, monday);
  const settlements = useSettlements(group?.id, monday);
  const markPaid = useMarkPaid();
  const undoPaid = useUndoPaid();

  const memberList = members.data ?? [];
  const memberIds = memberList.map((m) => m.id);
  const rows = expenses.data ?? [];

  const transfers = useMemo(() => {
    const balances = computeBalances(rows, memberIds);
    return computeTransfers(balances).filter((t) => t.amount >= 100);
  }, [rows, memberIds.join(",")]); // eslint-disable-line react-hooks/exhaustive-deps

  const profileOf = (id: string) => memberList.find((m) => m.id === id);
  const total = rows.reduce((sum, e) => sum + e.amount_ore, 0);

  const paidKey = (from: string, to: string) =>
    (settlements.data ?? []).find((s) => s.from_user === from && s.to_user === to);

  if (!group) {
    return (
      <AppShell title="Oppgjør">
        <NoGroup />
      </AppShell>
    );
  }

  const mine = transfers.filter((t) => t.from === user?.id);
  const incoming = transfers.filter((t) => t.to === user?.id);
  const others = transfers.filter((t) => t.from !== user?.id && t.to !== user?.id);

  return (
    <AppShell title="Ukens oppgjør" subtitle={`${group.name} · uke ${weekNumber(monday)}`}>
      <WeekPicker monday={monday} offset={offset} onChange={setOffset} />

      <div className="mt-4 rounded-3xl bg-card p-5 shadow-card">
        <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">
          {formatWeekRange(monday)}
        </p>
        <p className="money mt-1 text-[34px] leading-none font-bold">
          {formatKr(total)} <span className="text-xl text-muted-foreground">kr</span>
        </p>
        <p className="mt-2 text-[13px] text-muted-foreground">
          {transfers.length === 0
            ? "Ingenting å gjøre opp – alt er i balanse."
            : `${transfers.length} ${transfers.length === 1 ? "overføring" : "overføringer"} rydder opp hele uka.`}
        </p>
      </div>

      {transfers.length === 0 ? (
        <div className="mt-4 rounded-2xl border border-dashed border-border p-6 text-center">
          <span className="text-3xl">✅</span>
          <p className="mt-2 text-[14px] text-muted-foreground">
            Ingen skylder noen noe denne uka.
          </p>
        </div>
      ) : null}

      {mine.length > 0 ? (
        <Group title="Du skal betale">
          {mine.map((t) => {
            const to = profileOf(t.to);
            const paid = paidKey(t.from, t.to);
            return (
              <div key={`${t.from}-${t.to}`} className="rounded-3xl bg-card p-4 shadow-card">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-[17px] font-bold">{to?.full_name}</p>
                    <p className="text-[13px] text-muted-foreground">
                      Vipps {normalizePhone(to?.phone ?? "")}
                    </p>
                  </div>
                  <p className="money text-[26px] leading-none font-bold text-negative">
                    {formatKr(t.amount)} kr
                  </p>
                </div>

                {paid ? (
                  <div className="mt-4 flex items-center justify-between rounded-2xl bg-positive/12 px-4 py-3">
                    <span className="flex items-center gap-2 text-[14px] font-medium text-positive">
                      <Check className="size-4" strokeWidth={3} /> Merket som betalt
                    </span>
                    <button
                      type="button"
                      onClick={() => undoPaid.mutate(paid.id)}
                      className="tap text-[13px] text-muted-foreground underline"
                    >
                      Angre
                    </button>
                  </div>
                ) : (
                  <>
                    <a
                      href={vippsLink({
                        phone: to?.phone ?? "",
                        ore: t.amount,
                        message: `${group.name} – uke ${weekNumber(monday)}`,
                      })}
                      onClick={() =>
                        markPaid.mutate({
                          groupId: group.id,
                          weekStart: monday,
                          fromUser: t.from,
                          toUser: t.to,
                          amountOre: t.amount,
                        })
                      }
                      className="tap mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-vipps py-4 font-display text-lg font-bold tracking-wide text-vipps-foreground shadow-raised"
                    >
                      BETAL HER
                    </a>
                    <div className="mt-2 flex items-center justify-between gap-2 text-[12.5px] text-muted-foreground">
                      <span>
                        Åpner Vipps med {normalizePhone(to?.phone ?? "")} og{" "}
                        {formatKr(t.amount)} kr ferdig utfylt
                      </span>
                      <button
                        type="button"
                        aria-label="Kopier nummer"
                        onClick={async () => {
                          try {
                            await navigator.clipboard.writeText(normalizePhone(to?.phone ?? ""));
                            toast.success("Nummer kopiert");
                          } catch {
                            toast.error("Klarte ikke å kopiere");
                          }
                        }}
                        className="tap grid size-8 shrink-0 place-items-center rounded-lg bg-secondary"
                      >
                        <Copy className="size-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </Group>
      ) : null}

      {incoming.length > 0 ? (
        <Group title="Du skal få">
          {incoming.map((t) => {
            const from = profileOf(t.from);
            const paid = paidKey(t.from, t.to);
            return (
              <div
                key={`${t.from}-${t.to}`}
                className="flex items-center justify-between rounded-2xl bg-card p-4 shadow-card"
              >
                <div>
                  <p className="text-[15px] font-medium">{from?.full_name}</p>
                  <p className="text-[13px] text-muted-foreground">
                    {paid ? "Har merket oppgjøret som betalt" : "Venter på betaling"}
                  </p>
                </div>
                <p className="money text-[20px] font-bold text-positive">
                  {formatKr(t.amount)} kr
                </p>
              </div>
            );
          })}
        </Group>
      ) : null}

      {others.length > 0 ? (
        <Group title="Andre i kollektivet">
          {others.map((t) => (
            <div
              key={`${t.from}-${t.to}`}
              className="flex items-center justify-between rounded-2xl bg-card p-4 shadow-card"
            >
              <p className="text-[14px]">
                {profileOf(t.from)?.full_name} → {profileOf(t.to)?.full_name}
              </p>
              <p className="money text-[16px] font-bold">{formatKr(t.amount)} kr</p>
            </div>
          ))}
        </Group>
      ) : null}
    </AppShell>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-6">
      <h2 className="font-display text-lg font-bold">{title}</h2>
      <div className="mt-2.5 space-y-2.5">{children}</div>
    </section>
  );
}
