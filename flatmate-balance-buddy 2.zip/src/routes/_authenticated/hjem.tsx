import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { AppShell } from "@/components/AppShell";
import { NoGroup } from "@/components/NoGroup";
import { WeekPicker } from "@/components/WeekPicker";
import { useActiveGroup } from "@/hooks/useActiveGroup";
import { categoryOf } from "@/lib/categories";
import { useDeleteExpense, useMembers, useUser, useWeekExpenses } from "@/lib/data";
import { formatKr } from "@/lib/money";
import { computeBalances } from "@/lib/settle";
import { addWeeks, daysLeftInWeek, formatDayLong, parseISODate, weekStart } from "@/lib/week";

export const Route = createFileRoute("/_authenticated/hjem")({
  head: () => ({
    meta: [
      { title: "Ukens utlegg – Kollektivet" },
      {
        name: "description",
        content:
          "Se alle fellesutgifter i kollektivet denne uka, hva du har lagt ut og hva du skylder.",
      },
      { property: "og:title", content: "Ukens utlegg – Kollektivet" },
      {
        property: "og:description",
        content: "Full oversikt over ukens fellesutgifter i kollektivet.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { user } = useUser();
  const { group, isLoading } = useActiveGroup();
  const [offset, setOffset] = useState(0);
  const monday = useMemo(() => addWeeks(weekStart(), offset), [offset]);

  const members = useMembers(group?.id);
  const expenses = useWeekExpenses(group?.id, monday);
  const deleteExpense = useDeleteExpense();

  const memberIds = (members.data ?? []).map((m) => m.id);
  const rows = expenses.data ?? [];

  const total = rows.reduce((sum, e) => sum + e.amount_ore, 0);
  const myPaid = rows.filter((e) => e.paid_by === user?.id).reduce((s, e) => s + e.amount_ore, 0);
  const balances = useMemo(
    () => computeBalances(rows, memberIds),
    [rows, memberIds.join(",")], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const myNet = balances.find((b) => b.userId === user?.id)?.net ?? 0;

  const nameOf = (id: string) =>
    id === user?.id ? "deg" : (members.data ?? []).find((m) => m.id === id)?.full_name ?? "ukjent";

  const byDay = useMemo(() => {
    const map = new Map<string, typeof rows>();
    for (const e of rows) {
      const list = map.get(e.spent_on) ?? [];
      list.push(e);
      map.set(e.spent_on, list);
    }
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [rows]);

  const daysLeft = daysLeftInWeek(monday);

  if (isLoading) {
    return (
      <AppShell title="Kollektivet">
        <p className="text-[14px] text-muted-foreground">Laster…</p>
      </AppShell>
    );
  }

  if (!group) {
    return (
      <AppShell title="Kollektivet">
        <NoGroup />
      </AppShell>
    );
  }

  return (
    <AppShell title={group.name} subtitle={`${members.data?.length ?? 0} i kollektivet`}>
      <WeekPicker monday={monday} offset={offset} onChange={setOffset} />

      <section className="mt-4 rounded-3xl bg-primary p-5 text-primary-foreground shadow-raised">
        <p className="text-[12px] tracking-[0.14em] uppercase opacity-75">Fellesutgifter i uka</p>
        <p className="money mt-1 text-[40px] leading-none font-bold">
          {formatKr(total)} <span className="text-2xl">kr</span>
        </p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-primary-foreground/12 p-3">
            <p className="text-[11px] tracking-wide uppercase opacity-75">Du har lagt ut</p>
            <p className="money mt-0.5 text-xl font-bold">{formatKr(myPaid)} kr</p>
          </div>
          <div className="rounded-2xl bg-primary-foreground/12 p-3">
            <p className="text-[11px] tracking-wide uppercase opacity-75">
              {myNet < 0 ? "Du skylder" : myNet > 0 ? "Du får" : "Du er i balanse"}
            </p>
            <p className="money mt-0.5 text-xl font-bold">{formatKr(Math.abs(myNet))} kr</p>
          </div>
        </div>
        <p className="mt-3 text-[12px] opacity-75">
          {daysLeft > 0
            ? `${daysLeft} ${daysLeft === 1 ? "dag" : "dager"} igjen av uka`
            : "Uka er ferdig – klar for oppgjør"}
        </p>
      </section>

      <Link
        to="/oppgjor"
        className="tap mt-3 flex items-center justify-between rounded-2xl bg-card p-4 shadow-card"
      >
        <div>
          <p className="font-display text-[16px] font-bold">Ukens oppgjør</p>
          <p className="text-[13px] text-muted-foreground">Se hvem som skylder hvem</p>
        </div>
        <span className="rounded-xl bg-vipps px-3 py-2 font-display text-[13px] font-bold text-vipps-foreground">
          BETAL HER
        </span>
      </Link>

      <div className="mt-6 flex items-baseline justify-between">
        <h2 className="font-display text-lg font-bold">Utlegg</h2>
        <span className="text-[12px] text-muted-foreground">
          {rows.length} {rows.length === 1 ? "post" : "poster"}
        </span>
      </div>

      {rows.length === 0 ? (
        <div className="mt-3 rounded-2xl border border-dashed border-border p-6 text-center">
          <p className="text-[14px] text-muted-foreground">
            Ingen utlegg registrert denne uka. Trykk på pluss-knappen for å legge inn det første.
          </p>
        </div>
      ) : (
        <div className="mt-3 space-y-5">
          {byDay.map(([day, items]) => (
            <div key={day}>
              <p className="text-[12px] font-medium tracking-wide text-muted-foreground uppercase">
                {formatDayLong(parseISODate(day))}
              </p>
              <div className="mt-2 space-y-2">
                {items.map((e) => {
                  const cat = categoryOf(e.category);
                  const perPerson = Math.round(
                    e.amount_ore / Math.max(1, e.participants.length || 1),
                  );
                  const canDelete = e.created_by === user?.id || e.paid_by === user?.id;
                  return (
                    <div
                      key={e.id}
                      className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card"
                    >
                      <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-secondary text-xl">
                        {cat.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[15px] font-medium">{e.title}</p>
                        <p className="truncate text-[12.5px] text-muted-foreground">
                          {nameOf(e.paid_by)} la ut · deles på {e.participants.length || 1}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="money text-[15px] font-bold">{formatKr(e.amount_ore)} kr</p>
                        <p className="text-[12px] text-muted-foreground">
                          {formatKr(perPerson)} kr hver
                        </p>
                      </div>
                      {canDelete ? (
                        <button
                          type="button"
                          aria-label={`Slett ${e.title}`}
                          onClick={async () => {
                            try {
                              await deleteExpense.mutateAsync(e.id);
                              toast.success("Utlegget er slettet");
                            } catch {
                              toast.error("Klarte ikke å slette utlegget");
                            }
                          }}
                          className="tap grid size-9 shrink-0 place-items-center rounded-xl text-muted-foreground"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
