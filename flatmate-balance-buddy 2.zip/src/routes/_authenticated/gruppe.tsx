import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, Share2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { AppShell } from "@/components/AppShell";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useActiveGroup } from "@/hooks/useActiveGroup";
import { useCreateGroup, useJoinGroup, useMembers, useUser } from "@/lib/data";
import { cn } from "@/lib/utils";
import { normalizePhone } from "@/lib/vipps";

export const Route = createFileRoute("/_authenticated/gruppe")({
  head: () => ({
    meta: [
      { title: "Kollektivet ditt – gruppe og kode" },
      {
        name: "description",
        content:
          "Lag en gruppe for kollektivet, del den unike koden med de du bor med, og se alle medlemmene.",
      },
      { property: "og:title", content: "Kollektivet ditt – gruppe og kode" },
      {
        property: "og:description",
        content: "Del den unike koden så resten av kollektivet kan bli med.",
      },
    ],
  }),
  component: GroupPage,
});

function GroupPage() {
  const { user } = useUser();
  const { groups, group, selectGroup } = useActiveGroup();
  const members = useMembers(group?.id);
  const createGroup = useCreateGroup();
  const joinGroup = useJoinGroup();

  const [name, setName] = useState("");
  const [code, setCode] = useState("");

  async function handleCreate() {
    if (name.trim().length < 2) {
      toast.error("Gi kollektivet et navn");
      return;
    }
    try {
      const created = await createGroup.mutateAsync(name.trim());
      if (created?.id) selectGroup(created.id);
      setName("");
      toast.success("Gruppa er laget!");
    } catch {
      toast.error("Klarte ikke å lage gruppa");
    }
  }

  async function handleJoin() {
    const clean = code.trim().toUpperCase();
    if (clean.length !== 6) {
      toast.error("Koden er 6 tegn");
      return;
    }
    try {
      const joined = await joinGroup.mutateAsync(clean);
      if (joined?.id) selectGroup(joined.id);
      setCode("");
      toast.success("Du er med i kollektivet!");
    } catch {
      toast.error("Fant ingen gruppe med den koden");
    }
  }

  async function share() {
    if (!group) return;
    const text = `Bli med i «${group.name}» i Kollektivet. Koden er ${group.join_code}`;
    try {
      if (navigator.share) await navigator.share({ text });
      else {
        await navigator.clipboard.writeText(text);
        toast.success("Invitasjon kopiert");
      }
    } catch {
      /* avbrutt av brukeren */
    }
  }

  return (
    <AppShell title="Kollektivet" subtitle={group ? group.name : "Lag eller bli med i en gruppe"}>
      {group ? (
        <>
          <section className="rounded-3xl bg-primary p-5 text-primary-foreground shadow-raised">
            <p className="text-[12px] tracking-[0.14em] uppercase opacity-75">Unik kode</p>
            <p className="mt-1 font-display text-[40px] leading-none font-bold tracking-[0.18em]">
              {group.join_code}
            </p>
            <p className="mt-2 text-[13px] opacity-80">
              De du bor med skriver inn denne koden for å bli med i {group.name}.
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(group.join_code);
                  toast.success("Kode kopiert");
                }}
                className="tap flex items-center justify-center gap-2 rounded-xl bg-primary-foreground/15 py-3 text-[14px] font-medium"
              >
                <Copy className="size-4" /> Kopier
              </button>
              <button
                type="button"
                onClick={share}
                className="tap flex items-center justify-center gap-2 rounded-xl bg-primary-foreground/15 py-3 text-[14px] font-medium"
              >
                <Share2 className="size-4" /> Del
              </button>
            </div>
          </section>

          <section className="mt-6">
            <h2 className="font-display text-lg font-bold">
              Medlemmer ({members.data?.length ?? 0})
            </h2>
            <div className="mt-2.5 space-y-2">
              {(members.data ?? []).map((m) => (
                <div key={m.id} className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card">
                  <span className="grid size-10 shrink-0 place-items-center rounded-full bg-secondary font-display text-[15px] font-bold">
                    {m.full_name.slice(0, 1).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-medium">
                      {m.full_name}
                      {m.id === user?.id ? " (deg)" : ""}
                    </p>
                    <p className="truncate text-[12.5px] text-muted-foreground">
                      @{m.username} · {normalizePhone(m.phone)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {groups.length > 1 ? (
            <section className="mt-6">
              <h2 className="font-display text-lg font-bold">Bytt gruppe</h2>
              <div className="mt-2.5 space-y-2">
                {groups.map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => selectGroup(g.id)}
                    className={cn(
                      "tap flex w-full items-center justify-between rounded-2xl p-3.5 text-left",
                      g.id === group.id ? "bg-accent text-accent-foreground" : "bg-card shadow-card",
                    )}
                  >
                    <span className="text-[15px] font-medium">{g.name}</span>
                    {g.id === group.id ? <Check className="size-4" strokeWidth={3} /> : null}
                  </button>
                ))}
              </div>
            </section>
          ) : null}
        </>
      ) : null}

      <section className="mt-6 rounded-3xl bg-card p-5 shadow-card">
        <h2 className="font-display text-lg font-bold">Bli med med kode</h2>
        <p className="mt-1 text-[13px] text-muted-foreground">
          Har noen i kollektivet laget gruppa alt? Skriv inn koden deres.
        </p>
        <Input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          maxLength={6}
          placeholder="ABC123"
          autoCapitalize="characters"
          className="mt-3 h-14 rounded-xl bg-secondary text-center font-display text-2xl tracking-[0.2em]"
        />
        <button
          type="button"
          onClick={handleJoin}
          disabled={joinGroup.isPending}
          className="tap mt-3 flex w-full items-center justify-center rounded-2xl bg-primary py-3.5 font-display text-[15px] font-bold text-primary-foreground disabled:opacity-60"
        >
          Bli med
        </button>
      </section>

      <section className="mt-4 rounded-3xl bg-card p-5 shadow-card">
        <h2 className="font-display text-lg font-bold">Lag ny gruppe</h2>
        <div className="mt-3 space-y-1.5">
          <Label className="text-[13px] text-muted-foreground">Navn på kollektivet</Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={40}
            placeholder="Sofienberggata 12"
            className="h-13 rounded-xl bg-secondary text-base"
          />
        </div>
        <button
          type="button"
          onClick={handleCreate}
          disabled={createGroup.isPending}
          className="tap mt-3 flex w-full items-center justify-center rounded-2xl border border-border py-3.5 font-display text-[15px] font-bold disabled:opacity-60"
        >
          Lag gruppe
        </button>
      </section>
    </AppShell>
  );
}
