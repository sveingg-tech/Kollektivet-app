import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  signInWithUsername,
  signUpWithUsername,
  validateEmail,
  validatePhone,
  validateUsername,
} from "@/lib/auth";
import { useUser } from "@/lib/data";
import { cn } from "@/lib/utils";

type Search = { modus?: "ny" | "logg-inn" };

export const Route = createFileRoute("/auth")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>): Search => ({
    modus: search["modus"] === "ny" ? "ny" : "logg-inn",
  }),
  head: () => ({
    meta: [
      { title: "Logg inn – Kollektivet" },
      {
        name: "description",
        content:
          "Logg inn med brukernavn og passord, eller lag en ny bruker med navn og telefonnummer for å bli med i kollektivet.",
      },
      { property: "og:title", content: "Logg inn – Kollektivet" },
      {
        property: "og:description",
        content: "Brukernavn og passord er alt du trenger for å komme inn i kollektivgruppa.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { modus } = Route.useSearch();
  const navigate = useNavigate();
  const { user, ready } = useUser();
  const isSignup = modus === "ny";

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (ready && user) navigate({ to: "/hjem", replace: true });
  }, [ready, user, navigate]);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;

    const usernameError = validateUsername(username);
    if (usernameError) {
      toast.error(usernameError);
      return;
    }
    if (password.length < 6) {
      toast.error("Passordet må ha minst 6 tegn");
      return;
    }

    if (isSignup) {
      if (fullName.trim().length < 2) {
        toast.error("Skriv inn navnet ditt");
        return;
      }
      const phoneError = validatePhone(phone);
      if (phoneError) {
        toast.error(phoneError);
        return;
      }
      const emailError = validateEmail(email);
      if (emailError) {
        toast.error(emailError);
        return;
      }
    }

    setBusy(true);
    const error = isSignup
      ? await signUpWithUsername({ username, password, fullName, phone, email })
      : await signInWithUsername(username, password);
    setBusy(false);

    if (error) {
      const message = error.message.toLowerCase();
      if (message.includes("already registered") || message.includes("duplicate")) {
        toast.error("Brukernavnet er tatt. Prøv et annet.");
      } else if (message.includes("invalid login")) {
        toast.error("Feil brukernavn eller passord");
      } else {
        toast.error(error.message);
      }
      return;
    }

    toast.success(isSignup ? "Bruker opprettet!" : "Velkommen tilbake!");
    navigate({ to: "/hjem", replace: true });
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-[520px] flex-col px-6 pt-12 pb-10">
      <Link to="/" className="text-[13px] text-muted-foreground">
        ← Tilbake
      </Link>

      <h1 className="mt-8 font-display text-[34px] leading-none font-bold">
        {isSignup ? "Lag bruker" : "Logg inn"}
      </h1>
      <p className="mt-2 text-[14px] text-muted-foreground">
        {isSignup
          ? "Brukernavn og passord er innloggingen din. Navn og nummer bruker de andre til Vipps-oppgjøret."
          : "Skriv inn brukernavnet og passordet ditt."}
      </p>

      <div className="mt-6 grid grid-cols-2 gap-1.5 rounded-2xl bg-secondary p-1.5">
        <TabLink active={!isSignup} to="logg-inn" label="Logg inn" />
        <TabLink active={isSignup} to="ny" label="Ny bruker" />
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        {isSignup ? (
          <Field label="Navn">
            <Input
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              autoComplete="name"
              placeholder="Mari Hansen"
              className="h-13 rounded-xl bg-card text-base"
            />
          </Field>
        ) : null}

        <Field label="Brukernavn">
          <Input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoCapitalize="none"
            autoComplete="username"
            placeholder="mari"
            className="h-13 rounded-xl bg-card text-base"
          />
        </Field>

        {isSignup ? (
          <Field label="Telefonnummer (Vipps)">
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              inputMode="tel"
              autoComplete="tel"
              placeholder="912 34 567"
              className="h-13 rounded-xl bg-card text-base"
            />
          </Field>
        ) : null}

        {isSignup ? (
          <Field label="E-post">
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoCapitalize="none"
              autoComplete="email"
              placeholder="mari@epost.no"
              className="h-13 rounded-xl bg-card text-base"
            />
          </Field>
        ) : null}

        <Field label="Passord">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={isSignup ? "new-password" : "current-password"}
            placeholder="Minst 6 tegn"
            className="h-13 rounded-xl bg-card text-base"
          />
        </Field>

        <button
          type="submit"
          disabled={busy}
          className="tap mt-2 flex w-full items-center justify-center rounded-2xl bg-primary py-4 font-display text-base font-bold text-primary-foreground shadow-raised disabled:opacity-60"
        >
          {busy ? "Et øyeblikk…" : isSignup ? "Lag bruker" : "Logg inn"}
        </button>
      </form>
      <p className="mt-5 text-center text-[12.5px] text-muted-foreground">
        Ved å bruke appen godtar du vår{" "}
        <Link to="/personvern" className="underline">
          personvernerklæring
        </Link>
        .
      </p>
    </div>
  );
}

function TabLink({ active, to, label }: { active: boolean; to: "ny" | "logg-inn"; label: string }) {
  return (
    <Link
      to="/auth"
      search={{ modus: to }}
      replace
      className={cn(
        "tap rounded-xl py-2.5 text-center text-[14px] font-medium",
        active ? "bg-card text-foreground shadow-card" : "text-muted-foreground",
      )}
    >
      {label}
    </Link>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[13px] text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
