-- PROFILES
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- GROUPS
CREATE TABLE public.groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  join_code TEXT NOT NULL UNIQUE,
  created_by UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.groups TO authenticated;
GRANT ALL ON public.groups TO service_role;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

-- MEMBERS
CREATE TABLE public.group_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_id UUID NOT NULL REFERENCES public.groups ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (group_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.group_members TO authenticated;
GRANT ALL ON public.group_members TO service_role;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

-- EXPENSES
CREATE TABLE public.expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_id UUID NOT NULL REFERENCES public.groups ON DELETE CASCADE,
  paid_by UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'annet',
  amount_ore BIGINT NOT NULL CHECK (amount_ore > 0),
  spent_on DATE NOT NULL DEFAULT (now()::date),
  week_start DATE NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX expenses_group_week_idx ON public.expenses (group_id, week_start);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.expenses TO authenticated;
GRANT ALL ON public.expenses TO service_role;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

-- EXPENSE SHARES (who the expense is split between)
CREATE TABLE public.expense_shares (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  expense_id UUID NOT NULL REFERENCES public.expenses ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  UNIQUE (expense_id, user_id)
);
CREATE INDEX expense_shares_expense_idx ON public.expense_shares (expense_id);
GRANT SELECT, INSERT, DELETE ON public.expense_shares TO authenticated;
GRANT ALL ON public.expense_shares TO service_role;
ALTER TABLE public.expense_shares ENABLE ROW LEVEL SECURITY;

-- SETTLEMENTS (marking a week as paid)
CREATE TABLE public.settlements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_id UUID NOT NULL REFERENCES public.groups ON DELETE CASCADE,
  week_start DATE NOT NULL,
  from_user UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  to_user UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  amount_ore BIGINT NOT NULL,
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (group_id, week_start, from_user, to_user)
);
GRANT SELECT, INSERT, DELETE ON public.settlements TO authenticated;
GRANT ALL ON public.settlements TO service_role;
ALTER TABLE public.settlements ENABLE ROW LEVEL SECURITY;

-- HELPERS
CREATE OR REPLACE FUNCTION public.is_group_member(_group_id UUID, _user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE group_id = _group_id AND user_id = _user_id);
$$;

CREATE OR REPLACE FUNCTION public.shares_group(_a UUID, _b UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.group_members m1
    JOIN public.group_members m2 ON m1.group_id = m2.group_id
    WHERE m1.user_id = _a AND m2.user_id = _b
  );
$$;

-- POLICIES: profiles
CREATE POLICY "profiles_select_self_or_flatmates" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.shares_group(auth.uid(), id));
CREATE POLICY "profiles_insert_self" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_self" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- POLICIES: groups
CREATE POLICY "groups_select_members" ON public.groups FOR SELECT TO authenticated
  USING (public.is_group_member(id, auth.uid()));
CREATE POLICY "groups_insert_own" ON public.groups FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "groups_update_creator" ON public.groups FOR UPDATE TO authenticated
  USING (created_by = auth.uid()) WITH CHECK (created_by = auth.uid());

-- POLICIES: group_members
CREATE POLICY "members_select_same_group" ON public.group_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_group_member(group_id, auth.uid()));
CREATE POLICY "members_insert_self" ON public.group_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "members_delete_self" ON public.group_members FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- POLICIES: expenses
CREATE POLICY "expenses_select_members" ON public.expenses FOR SELECT TO authenticated
  USING (public.is_group_member(group_id, auth.uid()));
CREATE POLICY "expenses_insert_members" ON public.expenses FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.is_group_member(group_id, auth.uid()));
CREATE POLICY "expenses_update_owner" ON public.expenses FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR paid_by = auth.uid())
  WITH CHECK (public.is_group_member(group_id, auth.uid()));
CREATE POLICY "expenses_delete_owner" ON public.expenses FOR DELETE TO authenticated
  USING (created_by = auth.uid() OR paid_by = auth.uid());

-- POLICIES: expense_shares
CREATE POLICY "shares_select_members" ON public.expense_shares FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.expenses e WHERE e.id = expense_id AND public.is_group_member(e.group_id, auth.uid())));
CREATE POLICY "shares_insert_members" ON public.expense_shares FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.expenses e WHERE e.id = expense_id AND public.is_group_member(e.group_id, auth.uid())));
CREATE POLICY "shares_delete_owner" ON public.expense_shares FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.expenses e WHERE e.id = expense_id AND (e.created_by = auth.uid() OR e.paid_by = auth.uid())));

-- POLICIES: settlements
CREATE POLICY "settlements_select_members" ON public.settlements FOR SELECT TO authenticated
  USING (public.is_group_member(group_id, auth.uid()));
CREATE POLICY "settlements_insert_members" ON public.settlements FOR INSERT TO authenticated
  WITH CHECK (public.is_group_member(group_id, auth.uid()) AND (from_user = auth.uid() OR to_user = auth.uid()));
CREATE POLICY "settlements_delete_members" ON public.settlements FOR DELETE TO authenticated
  USING (from_user = auth.uid() OR to_user = auth.uid());

-- RPC: create a group with a unique code and add creator as member
CREATE OR REPLACE FUNCTION public.create_group(_name TEXT)
RETURNS public.groups LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _code TEXT;
  _g public.groups;
  _uid UUID := auth.uid();
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Ikke innlogget'; END IF;
  LOOP
    _code := upper(substring(replace(gen_random_uuid()::text, '-', '') from 1 for 6));
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.groups WHERE join_code = _code);
  END LOOP;
  INSERT INTO public.groups (name, join_code, created_by)
  VALUES (trim(_name), _code, _uid) RETURNING * INTO _g;
  INSERT INTO public.group_members (group_id, user_id) VALUES (_g.id, _uid);
  RETURN _g;
END;
$$;
GRANT EXECUTE ON FUNCTION public.create_group(TEXT) TO authenticated;

-- RPC: join a group by code
CREATE OR REPLACE FUNCTION public.join_group(_code TEXT)
RETURNS public.groups LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _g public.groups;
  _uid UUID := auth.uid();
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Ikke innlogget'; END IF;
  SELECT * INTO _g FROM public.groups WHERE join_code = upper(trim(_code));
  IF _g.id IS NULL THEN RAISE EXCEPTION 'Fant ingen gruppe med den koden'; END IF;
  INSERT INTO public.group_members (group_id, user_id) VALUES (_g.id, _uid)
  ON CONFLICT (group_id, user_id) DO NOTHING;
  RETURN _g;
END;
$$;
GRANT EXECUTE ON FUNCTION public.join_group(TEXT) TO authenticated;

-- RPC: check if a username is taken (needed before signup, unauthenticated)
CREATE OR REPLACE FUNCTION public.username_available(_username TEXT)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT NOT EXISTS (SELECT 1 FROM public.profiles WHERE lower(username) = lower(trim(_username)));
$$;
GRANT EXECUTE ON FUNCTION public.username_available(TEXT) TO anon, authenticated;